from polarishub import manage
def runHub():
    #print(sys.argv)
    manage.runserver()