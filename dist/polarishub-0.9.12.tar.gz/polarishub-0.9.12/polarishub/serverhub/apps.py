from django.apps import AppConfig


class ServerhubConfig(AppConfig):
    name = 'serverhub'
