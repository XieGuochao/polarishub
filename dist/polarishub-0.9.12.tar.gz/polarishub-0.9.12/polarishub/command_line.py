from polarishub import setup
def operation():
    setup.initialization()